"""
peer_database.py

Модуль работы с базой публичных пиров Yggdrasil.

Источник данных - официальный GitHub-репозиторий yggdrasil-network/public-peers
(структура: континент/страна.md, markdown-заголовки городов, пиры в виде
`протокол://хост:порт` в обратных кавычках). Список стран внутри континента
получаем через GitHub Contents API динамически, а не хардкодим - переживёт
добавление/удаление стран и городов без правок кода.

Никакого дискового кэша базы пиров нет - каждый раз, когда нужен кандидат
на замену, список скачивается заново с GitHub. Это сознательный компромисс
за простоту; единственная цена - если в момент реального сбоя окажется
недоступен ещё и сам GitHub, резервных данных не будет вообще.

Живость кандидата проверяется НАСТОЯЩИМ Yggdrasil-рукопожатием: пир
добавляется через runtime-команду `yggdrasilctl addPeer` (не требует
редактирования конфига и перезапуска демона - остальные уже работающие
соединения не затрагиваются), затем опрашивается `getPeers`, пока
состояние не станет Up либо не истечёт таймаут. Простой TCP-коннект
не используется - открытый порт ещё не значит, что Yggdrasil-протокол
там реально проходит (DPI может резать именно рукопожатие).
"""

import json
import logging
import re
import subprocess
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger("ygg_watchdog.peer_database")

GITHUB_API_BASE = "https://api.github.com/repos/yggdrasil-network/public-peers"
GITHUB_RAW_BASE = "https://raw.githubusercontent.com/yggdrasil-network/public-peers/master"

CONTINENTS = [
    "africa", "asia", "europe", "mena",
    "north-america", "oceania", "other", "south-america",
]

HTTP_TIMEOUT_SECONDS = 10

# Путь к yggdrasilctl - по умолчанию полагаемся на PATH (так и на Linux,
# и через systemd, если PATH настроен явно в unit-файле службы watchdog).
YGGCTL_PATH = "yggdrasilctl"

HANDSHAKE_TIMEOUT_SECONDS = 15    # сколько ждём, пока пир станет Up
HANDSHAKE_POLL_INTERVAL_SECONDS = 1.5


class PeerDatabaseError(Exception):
    pass


@dataclass
class Peer:
    uri: str
    country_slug: str  # имя файла без .md, например "russia"
    city: str
    protocol: str
    host: str
    port: int


# ------------------------------------------------------------------
# Разбор URI пира
# ------------------------------------------------------------------
_URI_RE = re.compile(
    r"^(?P<protocol>tcp|tls|quic|ws|wss|socks|sockstls)://"
    r"(?:\[(?P<host6>[^\]]+)\]|(?P<host4>[^:/?]+))"
    r":(?P<port>\d+)"
)


def parse_uri(uri: str) -> Optional[tuple[str, str, int]]:
    m = _URI_RE.match(uri.strip())
    if not m:
        return None
    host = m.group("host6") or m.group("host4")
    return m.group("protocol"), host, int(m.group("port"))


# ------------------------------------------------------------------
# Разбор markdown-файла страны
# ------------------------------------------------------------------
_HEADING_RE = re.compile(r"^\s*#{1,6}\s+(.+?)\s*$")
_URI_LINE_RE = re.compile(r"`((?:tcp|tls|quic|ws|wss|socks|sockstls)://[^`]+)`")


def parse_country_markdown(text: str, country_slug: str) -> list[Peer]:
    """Структурный разбор: заголовок любого уровня - название города,
    строки с URI в обратных кавычках после него - пиры этого города.
    Не привязан к конкретным названиям - переживёт изменения контента."""
    peers: list[Peer] = []
    current_city = "Unknown"

    for line in text.splitlines():
        heading_match = _HEADING_RE.match(line)
        if heading_match:
            current_city = heading_match.group(1)
            continue

        for uri_match in _URI_LINE_RE.finditer(line):
            uri = uri_match.group(1)
            parsed = parse_uri(uri)
            if parsed is None:
                logger.debug("Пропускаю нераспознанный URI: %s", uri)
                continue
            protocol, host, port = parsed
            peers.append(Peer(
                uri=uri, country_slug=country_slug, city=current_city,
                protocol=protocol, host=host, port=port,
            ))

    return peers


# ------------------------------------------------------------------
# Сеть: GitHub
# ------------------------------------------------------------------
def _http_get(url: str, as_json: bool = True):
    req = urllib.request.Request(url, headers={
        "User-Agent": "ygg-watchdog/1.0",
        "Accept": "application/vnd.github+json" if as_json else "*/*",
    })
    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SECONDS) as resp:
            raw = resp.read()
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise PeerDatabaseError(f"Не удалось обратиться к {url}: {e}") from e

    if not as_json:
        return raw.decode("utf-8", errors="replace")
    try:
        return json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError as e:
        raise PeerDatabaseError(f"Некорректный JSON от {url}: {e}") from e


def list_country_files() -> dict[str, str]:
    """{country_slug: raw_url} для всех .md файлов во всех континентах.

    Один запрос к git/trees (recursive=1) вместо восьми отдельных к
    Contents API (по одному на континент) - у GitHub жёсткий лимит на
    анонимные запросы (~60/час на IP), и восемь запросов за один вызов
    этой функции быстро съедали бы его при частых проверках watchdog
    во время реального затяжного сбоя пиров - то есть именно тогда,
    когда база пиров нужнее всего."""
    url = f"{GITHUB_API_BASE}/git/trees/master?recursive=1"
    try:
        data = _http_get(url)
    except PeerDatabaseError as e:
        logger.warning("Не удалось получить дерево репозитория: %s", e)
        return {}

    result: dict[str, str] = {}
    for item in data.get("tree", []):
        path = item.get("path", "")
        if item.get("type") != "blob" or not path.endswith(".md"):
            continue
        parts = path.split("/")
        if len(parts) != 2 or parts[0] not in CONTINENTS:
            continue
        continent, filename = parts
        slug = filename[:-3].lower()
        result[slug] = f"{GITHUB_RAW_BASE}/{path}"

    return result


def fetch_country_peers(country_slug: str) -> list[Peer]:
    """Скачивает и разбирает markdown-файл ОДНОЙ конкретной страны -
    без построения индекса по всем странам сразу (раз дискового кэша
    больше нет, незачем качать 190+ файлов ради одной страны)."""
    country_files = list_country_files()
    raw_url = country_files.get(country_slug.lower())
    if raw_url is None:
        raise PeerDatabaseError(f"Страна '{country_slug}' не найдена в репозитории")

    text = _http_get(raw_url, as_json=False)
    return parse_country_markdown(text, country_slug.lower())


def list_available_countries() -> list[str]:
    return sorted(list_country_files().keys())


def find_country_of_host(host: str) -> Optional[str]:
    """Ищет страну уже настроенного пира, перебирая country-файлы одного
    континента за раз, пока не найдёт совпадение по хосту. Дороже, чем
    было бы с кэшем, но кэша больше нет - это осознанный компромисс."""
    host_lower = host.lower()
    country_files = list_country_files()
    for slug, raw_url in country_files.items():
        try:
            text = _http_get(raw_url, as_json=False)
        except PeerDatabaseError:
            continue
        for peer in parse_country_markdown(text, slug):
            if peer.host.lower() == host_lower:
                return slug
    return None


# ------------------------------------------------------------------
# Взаимодействие с yggdrasilctl - настоящая проверка рукопожатия
# ------------------------------------------------------------------
def run_yggctl(args: list[str]) -> str:
    try:
        result = subprocess.run(
            [YGGCTL_PATH] + args,
            capture_output=True, text=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        raise PeerDatabaseError(f"Не удалось выполнить yggdrasilctl {args}: {e}") from e
    return (result.stdout or "") + (result.stderr or "")


def add_peer(uri: str) -> None:
    run_yggctl(["addPeer", f"uri={uri}"])


def remove_peer(uri: str) -> None:
    run_yggctl(["removePeer", f"uri={uri}"])


_LIVE_URI_SEARCH_RE = re.compile(
    r"(?:tcp|tls|quic|ws|wss|socks|sockstls)://(?:\[[^\]]+\]|[^\s│:/?]+):\d+"
)


def get_peer_state(uri: str) -> Optional[str]:
    """Возвращает состояние (Up/Down/...) для конкретного URI из getPeers,
    или None, если такой пир вообще не найден в выводе."""
    output = run_yggctl(["getPeers"])

    for raw_line in output.splitlines():
        line = raw_line.strip()
        if uri not in line:
            continue
        remainder = line.split(uri, 1)[1]
        tokens = [t for t in re.split(r"[│\s]+", remainder) if t]
        if tokens:
            return tokens[0]
    return None


def get_live_peers() -> dict[str, str]:
    """Возвращает {uri: state} для ВСЕХ пиров, которые сейчас числятся
    в живом getPeers (и основные из конфига, и любые runtime-добавленные -
    getPeers их не различает, различение - забота вызывающего кода)."""
    output = run_yggctl(["getPeers"])
    result: dict[str, str] = {}

    for raw_line in output.splitlines():
        line = raw_line.strip()
        match = _LIVE_URI_SEARCH_RE.search(line)
        if not match:
            continue
        uri = match.group(0)
        remainder = line[match.end():]
        tokens = [t for t in re.split(r"[│\s]+", remainder) if t]
        if tokens:
            result[uri] = tokens[0]

    return result


def verify_peer_handshake(
    uri: str,
    timeout: float = HANDSHAKE_TIMEOUT_SECONDS,
    poll_interval: float = HANDSHAKE_POLL_INTERVAL_SECONDS,
) -> bool:
    """Настоящая проверка: добавляет пира через runtime-команду addPeer,
    ждёт, пока getPeers не покажет состояние Up, затем убирает пира
    обратно (removePeer выполняется всегда, даже при ошибке - в finally),
    поскольку это проверочное добавление, а не постоянное решение."""
    add_peer(uri)
    try:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            state = get_peer_state(uri)
            if state and state.lower() == "up":
                return True
            time.sleep(poll_interval)
        return False
    finally:
        remove_peer(uri)


# ------------------------------------------------------------------
# Основная точка входа
# ------------------------------------------------------------------
def pick_replacement_peers(
    country_slug: str,
    exclude_hosts: set[str],
    count: int = 2,
    verify_handshake: bool = True,
) -> list[Peer]:
    """Возвращает до `count` пиров указанной страны, исключая уже
    настроенные хосты. Если verify_handshake=True (по умолчанию) -
    реально проверяет каждого кандидата через живое Yggdrasil-рукопожатие
    (addPeer -> ждём Up -> removePeer), а не просто TCP-коннектом."""
    all_peers = fetch_country_peers(country_slug)
    candidates = [p for p in all_peers if p.host.lower() not in exclude_hosts]

    if not verify_handshake:
        return candidates[:count]

    result: list[Peer] = []
    for peer in candidates:
        if len(result) >= count:
            break
        logger.info("Проверяю рукопожатие: %s", peer.uri)
        if verify_peer_handshake(peer.uri):
            result.append(peer)
            logger.info("  Up - подходит")
        else:
            logger.info("  не поднялся за отведённое время, пропускаю")

    return result
