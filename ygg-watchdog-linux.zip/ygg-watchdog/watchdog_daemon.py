#!/usr/bin/env python3
"""
watchdog_daemon.py

CLI-обвязка над watchdog_core: подкоманды для планировщика (tick) и для
ручного управления региональными пирами (add-region/remove-region), плюс
запись событий в файл-очередь для последующей доставки любым каналом
уведомлений (телефон, email, что угодно - этот файл не знает и не должен
знать, как события кому-то доставляются).

Использование:
    sudo python3 watchdog_daemon.py tick
    sudo python3 watchdog_daemon.py add-region nepal
    sudo python3 watchdog_daemon.py add-region nepal india   (несколько сразу)
    sudo python3 watchdog_daemon.py remove-region
    sudo python3 watchdog_daemon.py status
"""

import argparse
import json
import logging
import socket
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import peer_database as pd
import watchdog_core as wc

logger = logging.getLogger("ygg_watchdog.daemon")

_SYSTEM_QUEUE_PATH = Path("/var/lib/ygg-watchdog/events_queue.jsonl")
_USER_QUEUE_PATH = Path.home() / ".cache" / "ygg-watchdog" / "events_queue.jsonl"
_resolved_queue_path = None


def _get_queue_path() -> Path:
    global _resolved_queue_path
    if _resolved_queue_path is not None:
        return _resolved_queue_path
    for candidate in (_SYSTEM_QUEUE_PATH, _USER_QUEUE_PATH):
        try:
            candidate.parent.mkdir(parents=True, exist_ok=True)
            _resolved_queue_path = candidate
            return candidate
        except OSError:
            continue
    fallback = Path("/tmp/ygg-watchdog/events_queue.jsonl")
    fallback.parent.mkdir(parents=True, exist_ok=True)
    _resolved_queue_path = fallback
    return fallback


def append_events(events: list[wc.Event]) -> None:
    """Дописывает события в файл-очередь построчным JSON. Каждое событие
    получает метку времени и имя устройства - то самое требование
    'уведомление должно пояснять, с какого устройства пришло'."""
    if not events:
        return

    queue_path = _get_queue_path()
    device_name = socket.gethostname()
    now = datetime.now(timezone.utc).astimezone()  # локальное время с таймзоной

    with queue_path.open("a", encoding="utf-8") as f:
        for event in events:
            record = {
                "timestamp": now.isoformat(),
                "device": device_name,
                "kind": event.kind,
                "message": event.message,
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            logger.info("Событие записано в очередь: %s - %s", event.kind, event.message)


def cmd_tick(args: argparse.Namespace) -> int:
    config_path = wc.find_config_path()
    if config_path is None:
        print("Не найден yggdrasil.conf ни по одному из известных путей.", file=sys.stderr)
        return 1

    state = wc.load_state()
    events = wc.tick(config_path, state)
    wc.save_state(state)
    append_events(events)

    if events:
        for e in events:
            print(f"[{e.kind}] {e.message}")
    else:
        print("Без изменений.")
    return 0


def cmd_add_region(args: argparse.Namespace) -> int:
    state = wc.load_state()
    events = wc.cmd_add_region(state, args.countries)
    wc.save_state(state)
    append_events(events)

    for e in events:
        print(f"[{e.kind}] {e.message}")
    return 0


def cmd_remove_region(args: argparse.Namespace) -> int:
    state = wc.load_state()
    events = wc.cmd_remove_region(state)
    wc.save_state(state)
    append_events(events)

    for e in events:
        print(f"[{e.kind}] {e.message}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    state = wc.load_state()
    config_path = wc.find_config_path()

    print(f"Конфиг: {config_path if config_path else '(не найден)'}")
    print(f"Режим: {state.mode}")

    if config_path:
        main_peers = wc.read_main_peers(config_path)
        print(f"\nОсновные пиры ({len(main_peers)}):")
        for uri in main_peers:
            print(f"  {uri}")

    print(f"\nРезервные пиры ({len(state.backup_peers)}, регион: {state.backup_region}):")
    for uri in state.backup_peers:
        print(f"  {uri}")

    print(f"\nРегиональные пиры ({len(state.regional_peers)}, страны: {state.regional_countries}):")
    for uri in state.regional_peers:
        print(f"  {uri}")

    queue_path = _get_queue_path()
    if queue_path.exists():
        lines = queue_path.read_text(encoding="utf-8").splitlines()
        print(f"\nСобытий в очереди уведомлений: {len(lines)} (файл: {queue_path})")
    else:
        print(f"\nОчередь уведомлений пока пуста ({queue_path})")

    return 0


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    parser = argparse.ArgumentParser(description="Yggdrasil watchdog - CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_tick = subparsers.add_parser("tick", help="Один цикл проверки (для планировщика)")
    p_tick.set_defaults(func=cmd_tick)

    p_add = subparsers.add_parser("add-region", help="Включить региональный режим")
    p_add.add_argument("countries", nargs="+", help="Одна или несколько стран (slug из GitHub-репозитория, например 'nepal')")
    p_add.set_defaults(func=cmd_add_region)

    p_remove = subparsers.add_parser("remove-region", help="Снять региональные пиры, вернуться в normal")
    p_remove.set_defaults(func=cmd_remove_region)

    p_status = subparsers.add_parser("status", help="Показать текущее состояние")
    p_status.set_defaults(func=cmd_status)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
